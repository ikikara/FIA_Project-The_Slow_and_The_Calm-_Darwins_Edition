﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SampleContainer : MonoBehaviour {

	void Start () {
        DontDestroyOnLoad(this);
	}
	
}
